import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

/* 书途 · 原生锁屏提醒
   仅在 Capacitor 原生 App 里生效。网页版不加载本文件。
   作用：把「结束提醒」交给 Android 系统级闹钟（AlarmManager），
   锁屏 / 切后台 / 息屏都能准点弹出通知并响系统音，绕开浏览器后台限制。 */

if (Capacitor.isNativePlatform()) {
  (function () {
    var ID = 91001;
    var CH = 'shutu_timer';
    var timer = null;

    var css = document.createElement('style');
    css.textContent = [
      '#naBox{position:fixed;right:10px;bottom:10px;z-index:2147483000;max-width:250px;background:#fff;border:1px solid #D8D8D8;border-radius:12px;box-shadow:0 2px 10px rgba(0,0,0,.10);font:12px/1.5 -apple-system,system-ui,sans-serif;color:#262626}',
      '#naHead{padding:7px 11px;border-bottom:1px solid #EDEDED;display:flex;align-items:center;justify-content:space-between;gap:8px;font-weight:600}',
      '#naHead span{white-space:nowrap}',
      '#naTog{border:0;background:#F2F2F2;color:#333;border-radius:6px;padding:2px 8px;font-size:11px}',
      '#naBody{padding:9px 11px;display:none}',
      '#naBox.open #naBody{display:block}',
      '#naTip{margin:0 0 8px;color:#666;font-size:11px}',
      '#naRow{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:7px}',
      '#naRow button{border:1px solid #D0D0D0;background:#fff;color:#262626;border-radius:6px;padding:4px 9px;font-size:12px}',
      '#naRow button.on{background:#262626;color:#fff;border-color:#262626}',
      '#naMin{width:52px;border:1px solid #D0D0D0;border-radius:6px;padding:4px 6px;font-size:12px;color:#262626;background:#fff}',
      '#naGo{border:0;background:#262626;color:#fff;border-radius:6px;padding:4px 12px;font-size:12px;margin-left:5px}',
      '#naDel{border:0;background:none;color:#888;font-size:11px;padding:4px 2px;margin-left:4px}',
      '#naStat{margin-top:7px;font-size:11px;color:#1F1F1F;min-height:16px}'
    ].join('');
    document.head.appendChild(css);

    var box = document.createElement('div');
    box.id = 'naBox';
    box.innerHTML =
      '<div id="naHead"><span>⏰ 锁屏提醒</span><button id="naTog" type="button">展开</button></div>' +
      '<div id="naBody">' +
      '<p id="naTip">开始计时后，顺手点一下时长。到点由系统通知响，锁屏也听得见。</p>' +
      '<div id="naRow">' +
      '<button type="button" data-m="10">10 分</button>' +
      '<button type="button" data-m="25">25 分</button>' +
      '<button type="button" data-m="45">45 分</button>' +
      '<button type="button" data-m="60">60 分</button>' +
      '</div>' +
      '<input id="naMin" type="number" min="1" max="600" value="25" aria-label="自定义分钟"> 分' +
      '<button id="naGo" type="button">设定</button>' +
      '<button id="naDel" type="button">取消提醒</button>' +
      '<div id="naStat"></div>' +
      '</div>';
    document.body.appendChild(box);

    var head = document.getElementById('naHead');
    var tog = document.getElementById('naTog');
    var stat = document.getElementById('naStat');
    var minEl = document.getElementById('naMin');
    var row = document.getElementById('naRow');

    function setOpen(v) {
      box.classList.toggle('open', v);
      tog.textContent = v ? '收起' : '展开';
    }
    head.addEventListener('click', function (e) {
      if (e.target === tog) e.stopPropagation();
      setOpen(!box.classList.contains('open'));
    });
    tog.addEventListener('click', function (e) {
      e.stopPropagation();
      setOpen(!box.classList.contains('open'));
    });

    row.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-m]');
      if (!b) return;
      minEl.value = b.getAttribute('data-m');
      Array.prototype.forEach.call(row.querySelectorAll('button'), function (x) {
        x.classList.toggle('on', x === b);
      });
    });

    async function ensure() {
      try {
        var p = await LocalNotifications.checkPermissions();
        if (p.display !== 'granted') {
          var r = await LocalNotifications.requestPermissions();
          if (!r || r.display !== 'granted') {
            stat.textContent = '需要允许通知权限才能锁屏提醒';
            return false;
          }
        }
        try {
          await LocalNotifications.createChannel({
            id: CH,
            name: '计时结束',
            description: '专注 / 番茄 / 休息结束提醒',
            importance: 5,
            vibration: true
          });
        } catch (e) {}
        try {
          await LocalNotifications.checkExactNotificationSetting();
        } catch (e) {}
        return true;
      } catch (e) {
        stat.textContent = '通知初始化失败';
        return false;
      }
    }

    function hhmm(d) {
      return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    }

    document.getElementById('naGo').addEventListener('click', async function () {
      var m = parseInt(minEl.value, 10);
      if (!m || m < 1 || m > 600) {
        stat.textContent = '请填 1 ~ 600 之间的分钟数';
        return;
      }
      if (!(await ensure())) return;
      try {
        await LocalNotifications.cancel({ notifications: [{ id: ID }] });
        var at = new Date(Date.now() + m * 60000);
        await LocalNotifications.schedule({
          notifications: [{
            id: ID,
            title: '⏰ 书途 · 时间到',
            body: '这一段时间结束了，回来看看并结算吧',
            channelId: CH,
            autoCancel: true,
            schedule: { at: at, allowWhileIdle: true }
          }]
        });
        stat.textContent = '已设 ' + m + ' 分钟 · ' + hhmm(at) + ' 响（锁屏也会响）';
        setOpen(true);
      } catch (e) {
        stat.textContent = '设定失败：' + (e && e.message ? e.message : e);
      }
    });

    document.getElementById('naDel').addEventListener('click', async function () {
      try {
        await LocalNotifications.cancel({ notifications: [{ id: ID }] });
        stat.textContent = '已取消提醒';
      } catch (e) {
        stat.textContent = '取消失败';
      }
    });

    /* 点通知回到 App 时给个轻提示，不做动画 */
    try {
      LocalNotifications.addListener('localNotificationActionPerformed', function () {
        stat.textContent = '刚才那段结束了 ✓';
        setOpen(true);
      });
    } catch (e) {}

    ensure();
  })();
}
